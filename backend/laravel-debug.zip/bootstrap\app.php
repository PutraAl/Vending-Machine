<?php

use App\Http\Middleware\RoleMiddleware;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'role' => RoleMiddleware::class,
        ]);

        $middleware->trustProxies(at: '*');
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->report(function (\Throwable $e): void {
            $message = str_replace(
                ["\r", "\n"],
                ' ',
                $e->getMessage()
            );

            error_log(sprintf(
                '[VERCEL_EXCEPTION_SUMMARY] %s: %s at %s:%d',
                get_class($e),
                $message,
                basename($e->getFile()),
                $e->getLine()
            ));
        });
    })
    ->create();
