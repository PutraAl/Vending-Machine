<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
  public function up(): void
{
    Schema::create('products', function (Blueprint $table) {
        $table->id();

        $table->foreignId('category_id')
            ->constrained('product_categories')
            ->restrictOnDelete();

        $table->string('name');
        $table->text('description')->nullable();
        $table->decimal('price', 12, 2);
        $table->string('image')->nullable();
        $table->boolean('is_active')->default(true);

        $table->timestamps();

        $table->index('category_id');
        $table->index('is_active');
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
