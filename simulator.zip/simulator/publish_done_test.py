﻿import json
import time
import paho.mqtt.client as mqtt

payload = json.dumps({
    "machine_id": 3,
    "state": "DONE",
    "dispense_id": 9
})

client = mqtt.Client()
client.connect("127.0.0.1", 1883, 60)
client.loop_start()

try:
    for i in range(2):
        info = client.publish(
            "vending/machine/status",
            payload=payload,
            qos=0,
            retain=False
        )
        info.wait_for_publish()
        print(f"Pesan {i + 1} terkirim: {payload}")
        time.sleep(1)
finally:
    client.loop_stop()
    client.disconnect()
