import os
import ssl
import paho.mqtt.client as mqtt

from dotenv import load_dotenv

load_dotenv()


def create_mqtt_client():
    client = mqtt.Client(
        callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
        client_id=os.getenv(
            "MQTT_CLIENT_ID",
            "vending-simulator-001"
        )
    )

    client.username_pw_set(
        os.getenv("MQTT_USERNAME"),
        os.getenv("MQTT_PASSWORD")
    )

    client.tls_set(
        ca_certs=os.getenv("MQTT_CA_CERT"),
        cert_reqs=ssl.CERT_REQUIRED
    )

    return client